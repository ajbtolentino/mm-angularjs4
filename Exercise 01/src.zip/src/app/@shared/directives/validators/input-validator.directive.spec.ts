import { InputValidatorDirective } from './input-validator.directive';

describe('InputValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new InputValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
