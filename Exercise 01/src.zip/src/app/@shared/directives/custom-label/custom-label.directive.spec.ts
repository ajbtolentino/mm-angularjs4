import { CustomLabelDirective } from './custom-label.directive';

describe('CustomLabelDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomLabelDirective();
    expect(directive).toBeTruthy();
  });
});
