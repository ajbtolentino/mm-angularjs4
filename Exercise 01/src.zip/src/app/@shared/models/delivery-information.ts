import { FormGroup } from '@angular/forms';
export class DeliveryInformation {
  firstName: string;
  lastName: string;
  emailAddress: string;
  contactNumber: string;
  street: string;
  city: string;
  zip: string;
}
