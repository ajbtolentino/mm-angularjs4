export class PizzaSize {
  size: number;
  name: string;
  multiplier: number;

  constructor(size, name, multiplier) {
      this.size = size;
      this.name = name;
      this.multiplier = multiplier;
  }

  ngOnInit() {
  }

}
