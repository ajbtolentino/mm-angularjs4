export class DeliveryInformation {
  name: string;
  deliveryTo: string;

  constructor() { }

  ngOnInit() {
  }

}
